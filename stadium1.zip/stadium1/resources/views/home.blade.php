<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<style>
    .bg{
        background-image: url('storage/IMG.jpg');
        background-position-x: 50% !important;
        background-position-y: 50% !important;
        background-size: cover !important;
        height: 100vh;
    }
</style>
<body>
    <div class="bg">
        <h1>jshfk</h1>
    </div>

</body>
</html>
