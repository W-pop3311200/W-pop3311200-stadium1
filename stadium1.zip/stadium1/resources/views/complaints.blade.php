@include('main.mainlayout')
@include('main.header')
<h1>kjk</h1>
{{-- {{ $errors }} --}}

<form action="complaintsSave" method="POST">
    @csrf
    <input type="text" name="phone" placeholder="هاتف"><br>
    <span style="color: red">@error('phone'){{$message }} @enderror</span><br><br>
    <input type="text" name="comp" placeholder="اكتب التعليق او المشكلة" required="required" value= " {{old ('comp')}}">
    <span style="color: red">@error('comp'){{$message }} @enderror</span><br><br>
    <button type="submit" >ارسال</button>

</form>
