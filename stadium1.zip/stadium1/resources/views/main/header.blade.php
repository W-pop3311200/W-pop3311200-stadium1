<header>
    <h1 class="hader">Stadoum Gym</h1>
</header>
<footer class="footer"></footer>
<style>
    .hader {
        width: 100%;
        height: 50px;
        background-color: rgb(51, 51, 49);
        color: white;
        text-align: center;
        tex
    }

</style>
