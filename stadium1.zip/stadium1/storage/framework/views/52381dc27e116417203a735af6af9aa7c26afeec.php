<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<style>
    .background-imag {
        width: 100%;
        height: 100%;
        background-image: url('storage/home.jpg');
        background-size: contain;
        background-position: center;
        background-repeat: no-repeat;
        height: 100vh;

    }

</style>
<?php echo $__env->make('main.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;

<body>
    <div class="background-imag"></div>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\stadium1\resources\views/home.blade.php ENDPATH**/ ?>