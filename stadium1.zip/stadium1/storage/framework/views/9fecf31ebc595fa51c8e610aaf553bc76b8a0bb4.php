<?php echo $__env->make('main.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('main.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<h1>kjk</h1>


<form action="complaintsSave" method="POST">
    <?php echo csrf_field(); ?>
    <input type="text" name="phone" placeholder="هاتف"><br>
    <span style="color: red"><?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span><br><br>
    <input type="text" name="comp" placeholder="اكتب التعليق او المشكلة" required="required" value= " <?php echo e(old ('comp')); ?>">
    <span style="color: red"><?php $__errorArgs = ['comp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span><br><br>
    <button type="submit" >ارسال</button>

</form>
<?php /**PATH C:\xampp\htdocs\stadium1\resources\views/complaints.blade.php ENDPATH**/ ?>