<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Tymon\JWTAuth\Contracts\JWTSubject;

class users extends Authenticatable
{
    protected $table = 'users';

    protected $fillable = [
        'Badgenumber',
        'name',
        'email',
        'password',
        'api_token',
        'Gym_plass',
        'OPHONE',
    ];

    // protected $hidden = [
    //     'password',
    //     'remember_token',
    //     'Badgenumber',
    //     'api_token',
    // ];

    public function getJWTIdentifier()
    {
        return $this->getKey();
    }

    /**
     * Return a key value array, containing any custom claims to be added to the JWT.
     *
     * @return array
     */
    public function getJWTCustomClaims()
    {
        return [];
    }
}
