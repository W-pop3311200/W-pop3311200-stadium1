<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class poll extends Model
{

    protected $table = 'poll';

    protected $fillable = [
        'Scid', 'Sfrom'
    ];
}
