<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Class_setup extends Model
{
    protected $table = 'class_setup';

    protected $fillable = [
        'Scid', 'Sfrom'
    ];
}
