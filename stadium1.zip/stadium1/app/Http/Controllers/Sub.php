<?php

namespace App\Http\Controllers;

use App\Models\Subsal as dd;
use App\Models\Class_setup as calss;
use Illuminate\Http\Request;
use Illuminate\Support\facades\DB as DB;


class Sub extends Controller
{

    public function show()
    {
        $url = ('storage/Zomp.jpg');
        dd($url);
        return "<img scr='" . $url . "'/>";
    }
    public  function index()
    {
        $Sall = \DB::table('subsalses')
            ->join('users', 'subsalses.Scid', 'users.Badgenumber')
            ->get();

        $dd = dd::all();
        return  response()->json($Sall);
    }


    public  function Sub_cals()
    {
        $Sall = \DB::table('Class_setup')
            ->join('Day', 'Day.Day_id', 'Class_setup.id_Day')
            ->join('time', 'time.Time_id', 'Class_setup.id_Time')
            ->get();
        $dd = calss::all();
        return  response()->json($Sall);
    }


    public function cals()
    {
        $Sall = \DB::table('class_min')
            ->get();
        // $dd = calss::all();
        return  response()->json($Sall);
    }


    public function dd(Request $request)
    {
        $data = $request->validate([
            'Scid' => 'required'
        ]);
        $u = new dd();
        $u->Sid = $request->Sid;
        $u->Scid = $request->Scid;
        $u->said = $request->said;
        $u->Sdate = $request->Sdate;
        $u->Sfrom = $request->Sfrom;
        $u->Sto = $request->Sto;
        $u->Svalue = $request->Svalue;
        $u->Sdiscount = $request->Sdiscount;
        $u->Spaid = $request->Spaid;
        $u->Gym_plass = $request->Gym_plass;
        $u->Srest = $request->Srest;
        if ($u->save()) {
            return "ok";
        } else {
            return "no";
        }
    }
}
