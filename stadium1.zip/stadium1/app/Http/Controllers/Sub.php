<?php

namespace App\Http\Controllers;

use App\Models\Users as User;
use App\Models\Subsal as dd;
use App\Models\Class_setup as calss;
use App\Models\class_min as class_min;
use Illuminate\Http\Request;
use Illuminate\Support\facades\DB;
use App\Models\poll as poll;
use App\Models\users;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Hash;
use App\Traits\GeneraTraits;


class Sub extends Controller
{
    use GeneraTraits;

    public function newuser(Request $request)
    {
        $date = User::create([
            'Badgenumber' => $request->Badgenumber,
            'name' => $request->name,
            'password' => Hash::make($request->password),
            'api_token' => Str::random(length: 60),

        ]);
        return $date;
    }



    public function show()
    {
        $url = ('storage/Zomp.jpg');
        dd($url);
        return "<img scr='" . $url . "'/>";
    }
    public  function index(Request $request)
    {
        if ($request->api_password != env(key: "API_PASSWORD")) {
            return response()->json(['message' => 'Un']);
        }
        $Sall = \DB::table('subsalses')
            ->join('users', 'subsalses.Scid', 'users.Badgenumber')
            ->get();

        $dd = dd::all();
        // return  response()->json($Sall);
        if (!$Sall)
            return $this->returnError();
        return $this->returnData('data', $Sall, 'ok');
    }


    public  function Sub_cals($id)
    {
        $Sall = \DB::table('Class_setup')
            ->join('Day', 'Day.Day_id', 'Class_setup.id_Day')
            ->join('time', 'time.Time_id', 'Class_setup.id_Time')
            ->where('Class_setup.id_calss', $id)
            ->get();
        $dd = calss::all();
        return  response()->json($Sall);
    }


    public function cals()
    {

        $Sall = \DB::table('Class_Min')
            ->get();
        // $dd = calss::all();
        return  response()->json($Sall);
    }

    public function poll(Request $request)
    {

        $Gym_palss = $request->Gym_palss;
        $M_w = $request->M_w;
        $Sall = \DB::table('poll_gym')
            ->where('Gym_palss', $Gym_palss)
            ->where('M_w',  $M_w)

            ->get();
        // $dd = calss::all();
        return  response()->json($Sall);
    }

    //dataUser

    public function datauser(Request $request)
    {

        $OPHONE = $request->OPHONE;
        $Pass = $request->Pass;
        $Sall = \DB::table('users')
            ->where('OPHONE', $OPHONE)
            ->where('password',  $Pass)

            ->get();
        // $dd = calss::all();

        // return  response()->json($Sall);
        $row =  $Sall->count();
        if ($row > 0) {
            return  response()->json(['massage' => 'un', $Sall]);
        } else {

            $visible = ['massage' => 'un'];

            return response()->json($visible);
        }
    }





    public function dd(Request $request)
    {
        $data = $request->validate([
            'Scid' => 'required'
        ]);
        $u = new dd();
        $u->Sid = $request->Sid;
        $u->Scid = $request->Scid;
        $u->said = $request->said;
        $u->Sdate = $request->Sdate;
        $u->Sfrom = $request->Sfrom;
        $u->Sto = $request->Sto;
        $u->Svalue = $request->Svalue;
        $u->Sdiscount = $request->Sdiscount;
        $u->Spaid = $request->Spaid;
        $u->Gym_plass = $request->Gym_plass;
        $u->Srest = $request->Srest;
        if ($u->save()) {
            return "ok";
        } else {
            return "no";
        }
    }
}
