<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
// use App\Models\User as User;
use App\Models\Users as User;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;

class RegisterController extends Controller
{

    public function loginu(Request $request)
    {
        // return "ok";
        if (auth()->attempt([
            'OPHONE' => $request->input(key: 'ophoe'),
            'password' => $request->input(key: 'password')
        ])) {
            $user = auth()->user();
            $user->api_token = Str::random(length: 60);
            $user->save();
            return  response()->json(['code' => '200', $user]);
        }
        return response()->json(['code' => '201']);
    }

    public function logoutt(Request $request)
    {

        if (auth()->attempt([
            'api_token' => $request->input(key: 'api_token'),

        ])) {
            $user = auth()->User();
            $user->api_token = null;
            $user->save();
            // return $user;
            return response()->json([$status = 200]);
        }
        return response()->json([], $status = 201);
        // return 'dd';
    }

    public function register(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'Badgenumber' => 'required',
        ]);
        if ($request->api_password != env(key: "API_PASSWORD")) {
            return response()->json(['message' => 'Un']);
        }
        if ($validator->fails()) {
            return $validator->errors();
        } else {
            $date = User::create([
                'Badgenumber' => $request->Badgenumber,
                'name' => $request->name,
                'OPHONE' => $request->OPHONE,
                'email' => $request->email,
                'password' => Hash::make($request->password),
                'api_token' => Str::random(length: 60),
                'Gym_plass' => $request->Gym_plass,
            ]);
        };


        return $date;
    }
}
