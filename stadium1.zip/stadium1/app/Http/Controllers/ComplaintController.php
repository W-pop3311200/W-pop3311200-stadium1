<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\Validator;

use Illuminate\Http\Request;
use App\Models\complaint;

class ComplaintController extends Controller
{
    function comp_save(Request $req)
    {
        // Validator::make([
        //     'comp'=>'required',

        // ]);

        $req->validate([
            'phone'=>'required',
            'comp'=>'required |min:10',

        ]);
        $date=new complaint;
        $date->phone=$req->phone;
        $date->complaints=$req->comp;
        $date->save();

    return $req->input();

}


}
