<?php

namespace App\Traits;

trait GeneraTraits
{

    public function returnError()
    {

        return response()->json([
            'status' => false,
            'errNum' => 'S001',
            'mag' => 'noFuond'
        ]);
    }
    public function returnData($key, $value, $msg = "")
    {
        return response()->json([
            'status' => true,
            'errNum' => "S000",
            'msg' => $msg,
            $key =>  $value
        ]);
    }
}
