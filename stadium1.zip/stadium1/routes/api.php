<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Sub;
use App\Http\Controllers\Api\RegisterController;
use Illuminate\Routing\RouteRegistrar;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/
//new


// Route::middleware('auth:api')->post('/logout', [RegisterController::class, 'logoutt']);
//old
Route::post('/chek', [Sub::class, 'chek']);

Route::post('/userid', [Sub::class, 'datauser']);
Route::post('/subb', [Sub::class, 'dd']);
Route::get('/ss', [Sub::class, 'index']);
Route::post('/cla/{id}', [Sub::class, 'Sub_cals']);
Route::get('/cla1', [Sub::class, 'cals']);
Route::get('/ss1', [Sub::class, 'show']);
Route::post('/poll', [Sub::class, 'poll']);

// Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
//     return $request->user();
// });


Route::group(['middleware' => ['api', 'checkpassword'], 'namespace'  => 'Api'], function () {
    Route::post('/ss', [Sub::class, 'index']);
    Route::post('/register', [RegisterController::class, 'register']);
    Route::post('/login', [RegisterController::class, 'loginu']);
    Route::post('/logout', [RegisterController::class, 'logoutt']);
});
