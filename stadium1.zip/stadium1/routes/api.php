<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Sub;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::post('/subb', [Sub::class, 'dd']);
Route::get('/ss', [Sub::class, 'index']);
Route::get('/cla', [Sub::class, 'Sub_cals']);
Route::get('/cla1', [Sub::class, 'cals']);
Route::get('/ss1', [Sub::class, 'show']);

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});
